package com.lumbreras.pruebatecnica;

import java.text.BreakIterator;

public class Utils extends Registro {

    //Quien envia
    public static final String EMAIL = "luis4450x@gmail.com";

    //password
    public static final String PASSWORD = "hola123+";

}
