package com.lumbreras.pruebatecnica;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.util.HashMap;
import java.util.Map;

public class Registro extends AppCompatActivity {

    EditText email,password,nombre,telefono;
    Button btnRegistro, btnVolver;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        email = findViewById(R.id.txtEmail);
        password = findViewById(R.id.txtPassword);
        nombre = findViewById(R.id.txtNombre);
        telefono = findViewById(R.id.txtTelefono);
        btnRegistro = findViewById(R.id.btnRegistro);
        btnVolver = findViewById(R.id.btnVolver);
        mAuth = FirebaseAuth.getInstance();

        btnVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Login.class));
                finish();
            }
        });

        btnRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mAuth.createUserWithEmailAndPassword(email.getText().toString(),password.getText().toString())
                        .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                            @Override
                            public void onSuccess(AuthResult authResult) {
                                Map<String,Object> userInfo = new HashMap<>();
                                userInfo.put("nombre", nombre.getText().toString());
                                userInfo.put("email", email.getText().toString());
                                userInfo.put("telefono",telefono.getText().toString());
                                userInfo.put("password",password.getText().toString());
                                envio();
                                Toast.makeText(getApplicationContext(),"Cuenta creada",Toast.LENGTH_SHORT).show();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(),"Error al crear cuenta",Toast.LENGTH_SHORT).show();
                    }
                });

            }
        });
    }
    private void envio(){
        String correo = email.getText().toString();
        String mensaje = "EL REGISTRO SE HA COMPLETADO EXITOSAMENTE";
        String asunto = "REGISTRO COMPLETADO";

        //ENVIO CORREO
        new JavaMailAPI(Registro.this,correo,asunto,mensaje).execute();
    }

}